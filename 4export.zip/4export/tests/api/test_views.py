from flask_testing import TestCase

class ApiTestCase(TestCase):

    def create_app(self):
        return create_app("testing")

    def setUp(self):
        db.create_all()
        db.session.commit()

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def create_user(self, username="Test", password="test"):
        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()
        return user

    def login(self, username="Test", password="test"):
        return self.client.post(url_for("auth.login"), data=dict(
            username=username,
            password=password
        ), follow_redirects=True)

    def logout(self):
        return self.client.get(url_for("auth.logout"), follow_redirects=True)


class TestApiUser(ApiTestCase):

    def test_returns_not_authorization_for_not_logged_user(self):
        pass
    
    def test_returns_json_response_for_get_request(self):
        pass

    def test_returns_not_found_when_unknown_user(self):
        pass

    def test_returns_not_found_for_user_with_private_profile(self):
        pass

    def test_creates_client_with_put_request(self):
        pass

    def test_updates_client_with_put_request(self):
        pass

    def test_deletes_client_with_delete_request(self):
        pass

    def test_delete_request_requires_password_confirmation(self):
        pass

    
    

    

class TestApiTasks(ApiTestCase):
    pass

class TestApiNotes(ApiTestCase):
    pass

class TestApiProjects(ApiTestCase):
    pass

class TestApiMilestones(ApiTestCase):
    pass